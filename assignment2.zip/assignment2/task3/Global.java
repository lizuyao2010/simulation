import java.util.*;

public class Global{
	public static final int READY = 1, DEAD = 2;
	public static double time = 0,previousTime=0,brokenNumber=0;
    public static ArrayList<Component> cpList = new ArrayList<Component>();
}
